<?php $__env->startSection('title',__('site.print_services')); ?>
<?php $lang = LaravelLocalization::getCurrentLocale(); ?>
<?php $__env->startSection('custom-style'); ?>
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/home-light.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('assets/rtl/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/rtl/css/home-light.css')); ?>" rel="stylesheet">
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Banner Section -->
    <section class="page-banner">
        <div class="image-layer"></div>

        <div class="banner-inner">
            <div class="faded-text light">
                <div class="f-text"><span><?php echo app('translator')->get('site.Services'); ?></span></div>
            </div>
            <div class="auto-container">
                <div class="inner-container clearfix">
                    <h1><?php echo e($print_name['title_'.$lang]); ?></h1>
                    <div class="page-nav">
                        <ul class="bread-crumb clearfix">
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('site.Home'); ?></a></li>
                            <li><a href="<?php echo e(route('print.index')); ?>"><?php echo app('translator')->get('site.Print'); ?></a></li>
                            <li class="active"><?php echo e($print_name['title_'.$lang]); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Banner Section -->


    <!--service Section-->
    <section class="team-section">
        <div class="bubble-dotted">
            <span class="dotted dotted-1"></span>
            <span class="dotted dotted-2"></span>
            <span class="dotted dotted-3"></span>
            <span class="dotted dotted-4"></span>
            <span class="dotted dotted-5"></span>
            <span class="dotted dotted-6"></span>
            <span class="dotted dotted-7"></span>
            <span class="dotted dotted-8"></span>
            <span class="dotted dotted-9"></span>
            <span class="dotted dotted-10"></span>
        </div>
        <div class="faded-text">
            <div class="f-text"><span><?php echo app('translator')->get('site.Services'); ?></span></div>
        </div>
        <div class="auto-container">
            <div class="sec-title centered mb-4">
                <div class="sub-title"><?php echo app('translator')->get('site.print_services'); ?></div>
                <h2><?php echo e($print_name['title_'.$lang]); ?></h2>
            </div>
            <hr>

            <section class="portfolio-section-four">
                <div class="auto-container">
                    <div class="row clearfix">
                        <?php $__currentLoopData = $print; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="gallery-item-two col-lg-4 col-md-6 col-sm-12">
                                <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                    <div class="image-box">
                                        <figure class="image">
                                            <?php if($pr->imageCategoryPrints()->exists()): ?>
                                            <a class="lightbox-image" href="<?php echo e(asset('uploads/' . $pr->image)); ?>"><img
                                                    src="<?php echo e(asset('uploads/' . $pr->imageCategoryPrints[0]->image)); ?>" alt=""></a>
                                                    <?php endif; ?>
                                        </figure>
                                        <div class="hover-box">
                                            <div class="hover-inner">
                                                <div class="content">
                                                    <h4><a
                                                            href="<?php echo e(route('print.service_details', $pr->id)); ?>"><?php echo e($pr['title_' . $lang]); ?></a>
                                                    </h4>
                                                    <div class="separator"><span class="dot"></span></div>
                                                </div>
                                            </div>
                                            <div class="zoom-btn">
                                                <?php if($pr->imageCategoryPrints()->exists()): ?>
                                                <a class="lightbox-image zoom-link"
                                                    href="<?php echo e(asset('uploads/' .  $pr->imageCategoryPrints[0]->image)); ?>"
                                                    data-fancybox="gallery"><span class="icon flaticon-expand"></span></a>
                                                    <?php endif; ?>
                                            </div>
                                            <div class="link-btn">
                                                <a href="<?php echo e(route('print.service_details', $pr->id)); ?>"><span
                                                        class="icon flaticon-link-1"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/pages/print_service.blade.php ENDPATH**/ ?>