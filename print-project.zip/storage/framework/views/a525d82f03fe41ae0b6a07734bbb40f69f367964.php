<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('dashboard/assets/libs/flatpickr/flatpickr.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dashboard/assets/libs/selectize/css/selectize.bootstrap3.css')); ?>" rel="stylesheet"
    type="text/css" />

    <link href="<?php echo e(asset('dashboard/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard/assets/libs/datatables.net-select-bs4/css//select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">الملف الشخصي</a></li>
                        <li class="breadcrumb-item active">      لوحة التحكم</li>
                    </ol>
                </div>
                <h4 class="page-title">      لوحة التحكم</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">


    </div>
    <!-- end row-->

    <!-- end page title -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">اراء العملاء</h4>


                    <table id="basic-datatable" class="table dt-responsive nowrap w-100">

                        <thead>
                            <tr>
                                <th> رقم التسلسل</th>
                                <th> اسم العميل</th>
                                <th> Client Name</th>
                                <th> صورة العميل   </th>
                                <th>ادارة</th>
                            </tr>
                        </thead>


                        <tbody>
                            <?php $__currentLoopData = $testmonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testmonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                 <td><?php echo e($testmonial->name_ar); ?></td>
                                 <td><?php echo e($testmonial->name_en); ?></td>
                                 <td><img src="<?php echo e(asset('uploads/'.$testmonial->image)); ?> " height="100px" width="100px" alt=""></td>

                                <td>
                                    <form action="<?php echo e(route('testmonial.destroy',$testmonial->id)); ?>" method="POST" class="remove-record-model">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger deleteExpense" ><i class="mdi mdi-delete"></i></button>

                                    </form>
                                     <a type="button" href="<?php echo e(route('testmonial.edit',$testmonial->id)); ?>" class="btn btn-success waves-effect waves-light " ><i class="mdi mdi-pencil-outline"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->




</div>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('dashboard/assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>

<script src="<?php echo e(asset('dashboard/assets/libs/selectize/js/standalone/selectize.min.js')); ?>"></script>

<!-- Dashboar 1 init js-->
<script src="<?php echo e(asset('dashboard/assets/js/pages/dashboard-1.init.js')); ?>"></script>


<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-buttons/js/buttons.flash.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/datatables.net-select/js/dataTables.select.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/js/pages/datatables.init.js')); ?>"></script>

<script>
    $(document).on('click','.deleteExpense',function(){
            var userID=$(this).attr('data-userid');
            console.log(userID)
            $('#app_id').val(userID);
            $('#applicantDeleteModal').modal('show');
        });

        $(document).on('click','.Endless','.Endless',function(){
            $('#applicantDeleteModal').modal('hide');
        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/dashboard/testmonial/index.blade.php ENDPATH**/ ?>