<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('layouts-admin.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </head>

    <body class="loading auth-fluid-pages pb-0">

        <div class="auth-fluid">
            <!--Auth fluid left content -->
            <div class="auth-fluid-form-box">
                <div class="align-items-center d-flex h-100">
                    <div class="card-body">

                        <!-- Logo -->
                        <div class="auth-brand text-center text-lg-start">
                            <div class="auth-logo">
                                <a href="<?php echo e(route('home')); ?>" class="logo logo-dark text-center">
                                    <span class="logo-lg">
                                        <img src="<?php echo e(asset('dashboard/assets/images/logo-dark.png')); ?>" alt="" height="22">
                                    </span>
                                </a>
            
                                <a href="<?php echo e(route('home')); ?>" class="logo logo-light text-center">
                                    <span class="logo-lg">
                                        <img src="<?php echo e(asset('dashboard/assets/images/logo-light.png')); ?>" alt="" height="22">
                                    </span>
                                </a>
                            </div>
                        </div>

                        <!-- title-->
                        <h4 class="mt-0"> تسجيل دخول</h4>
                        <p class="text-muted mb-4">أدخل عنوان بريدك الإلكتروني وكلمة المرور للوصول إلى الحساب.</p>

                        <!-- form -->
                        <form method="POST" action="<?php echo e(route('login')); ?>" >
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="emailaddress" class="form-label">البريد الالكتروني</label>
                                

                               
                                <input class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" id="emailaddress" name="email" required="" value="<?php echo e(old('email')); ?>" placeholder="Enter your email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                               
                                <label for="password" class="form-label">كلمة المرور</label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="password" class="form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Enter your password">
                                    

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <div class="input-group-text" data-password="false">
                                        <span class="password-eye"></span>
                                    </div>
                                </div>
                                
                            </div>
                            
                            <div class="mb-3">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="remember" id="checkbox-signin" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    
                                    <label class="form-check-label" for="checkbox-signin">تذكرني</label>
                                </div>
                            </div>
                            <div class="text-center d-grid">
                                <button class="btn btn-primary" type="submit">دخول  </button>
                            </div>
                            <!-- social-->
                            
                        </form>
                        <!-- end form-->

                        <!-- Footer-->
                       

                    </div> <!-- end .card-body -->
                </div> <!-- end .align-items-center.d-flex.h-100-->
            </div>
            <!-- end auth-fluid-form-box-->

            <!-- Auth fluid right content -->
            
            <!-- end Auth fluid right content -->
        </div>
        <!-- end auth-fluid-->

        <?php echo $__env->make('layouts-admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </body>
</html>

















                    
                
<?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/auth/login.blade.php ENDPATH**/ ?>