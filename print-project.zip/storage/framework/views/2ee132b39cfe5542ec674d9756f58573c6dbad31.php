
<?php $__env->startSection('custom-style'); ?>
<link href="<?php echo e(asset('assets/css2/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css2/home-light.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<!-- Banner Section -->
<section class="page-banner">
    <div class="banner-inner">
        <div class="faded-text light"><div class="f-text"><span>contact</span></div></div>
        <div class="auto-container">
            <div class="inner-container clearfix">
                <h1>contact us</h1>
                <div class="page-nav">
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">contact</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Banner Section -->

<!--Contact Section-->
<section class="contact-section">
    <div class="auto-container">

        <div class="row clearfix">

            <div class="form-column col-lg-6 col-md-12">
                <div class="inner">
                    <div class="sec-title left-aligned">
                        <div class="sub-title">Contact</div>
                        <!-- <h2>drop us a line with estimate</h2> -->
                    </div>
                    <div class="form-box">
                        <div class="default-form contact-form">
                            <form method="post" action="sendemail.php" id="contact-form" novalidate="novalidate">

                                <div class="form-group">
                                    <div class="field-inner">
                                        <input type="text" name="username" placeholder="Enter your name" required="" value="">
                                        <div class="field-icon"><span class="flaticon-people"></span></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="field-inner">
                                        <input type="text" name="phone" placeholder="Enter your phone" required="" value="">
                                        <div class="field-icon"><span class="flaticon-call"></span></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="field-inner">
                                        <input type="email" name="email" placeholder="Enter your email" required="" value="">
                                        <div class="field-icon"><span class="flaticon-envelope"></span></div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="field-inner">
                                        <textarea name="message" placeholder="Type your message" required=""></textarea>
                                        <div class="field-icon"><span class="flaticon-edit"></span></div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="btn-box">
                                        <button type="submit" class="theme-btn btn-style-two" ><span class="btn-title">Submit Now</span></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="map-column col-lg-6 col-md-12">
                <div class="inner">
                    <!--Map Box-->
                    <div class="map-box">
                        <div class="map-canvas"
                            data-zoom="12"
                            data-lat="-37.817085"
                            data-lng="144.955631"
                            data-type="roadmap"
                            data-hue="#ffc400"
                            data-title="Singapore"
                            data-icon-path="<?php echo e(asset('assets/images/icons/map-marker.png')); ?>"
                            data-content="Singapore VIC 3000, USA<br><a href='mailto:info@youremail.com'>info@youremail.com</a>">
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

  <!--Contact Section-->
  <section class="info-section">


    <div class="auto-container">

        <div class="info">
            <div class="row clearfix">
                <!--Info Block-->
                <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                    <div class="inner hvr-bob">
                        <div class="icon-box"><span class="flaticon-call"></span></div>
                        <h4>phone number</h4>
                        <ul>
                            <li><a href="tel:+8767676575498">+8767 6765 7549 8</a></li>
                            <li><a href="tel:+8767676575498">+8(098) 6765 7549 8</a></li>
                        </ul>
                    </div>
                </div>
                <!--Info Block-->
                <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                    <div class="inner hvr-bob">
                        <div class="icon-box"><span class="flaticon-envelope"></span></div>
                        <h4>email address</h4>
                        <ul>
                            <li><a href="mailto:info@webmail.com">info@webmail.com</a></li>
                            <li><a href="mailto:example@mail.co">example@mail.co</a></li>
                        </ul>
                    </div>
                </div>
                <!--Info Block-->
                <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                    <div class="inner hvr-bob">
                        <div class="icon-box"><span class="flaticon-worldwide-1"></span></div>
                        <h4>web address</h4>
                        <ul>
                            <li><a href="http://www.exapmple.com">exapmple.com</a></li>
                            <li><a href="http://www.jobs.exapmple.com">jobs.exapmple.com</a></li>
                        </ul>
                    </div>
                </div>
                <!--Info Block-->
                <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                    <div class="inner hvr-bob">
                        <div class="icon-box"><span class="flaticon-placeholder-3"></span></div>
                        <h4>office address</h4>
                        <ul>
                            <li> <p style="color:#4216c7;">Egypt,Giza, Mohandeseen</p> </li>
                            <!-- <li>London, UK</li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>



    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/pages/translate_contact.blade.php ENDPATH**/ ?>