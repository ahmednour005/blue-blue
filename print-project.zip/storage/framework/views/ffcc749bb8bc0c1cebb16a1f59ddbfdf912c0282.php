<?php $lang = LaravelLocalization::getCurrentLocale(); ?>
<?php $__env->startSection('title',__('site.About')); ?>
<?php $__env->startSection('custom-style'); ?>
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/home-light.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('assets/rtl/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/rtl/css/home-light.css')); ?>" rel="stylesheet">
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Banner Section -->
    <section class="page-banner">
        <div class="image-layer"></div>

    <div class="banner-inner">
        <div class="faded-text light">
            <div class="f-text"><span><?php echo app('translator')->get('site.About'); ?></span></div>
        </div>
        <div class="auto-container">
            <div class="inner-container clearfix">
                <h1><?php echo app('translator')->get('site.About_us'); ?></h1>
                <div class="page-nav">
                    <ul class="bread-crumb clearfix">
                        <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('site.Home'); ?></a></li>
                        <li class="active"><?php echo app('translator')->get('site.About_us'); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--End Banner Section -->

    <section class="about-section-three" id="scroll-section">
        <figure class="floated-image-1"><img src="<?php echo e(asset('assets/images/resource/featured-image-8.jpg')); ?>" alt="">
        </figure>
        <figure class="floated-image-2"><img src="<?php echo e(asset('assets/images/resource/featured-image-9.jpg')); ?>" alt="">
        </figure>
        <div class="auto-container">

            <div class="row clearfix">
                <!--Text Column-->
                <div class="text-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        <div class="sec-title-three left-aligned">
                            <div class="sub-title"><?php echo app('translator')->get('site.About_us'); ?></div>
                            <h2><?php echo app('translator')->get('site.About_us_title'); ?></h2>
                            <div class="lower-text"><?php echo app('translator')->get('site.About_us_sub_title'); ?></div>
                        </div>
                        <div class="text-content">
                            <div class="text-block">
                                <div class="title">
                                    <span class="count">01</span>
                                    <h4><?php echo app('translator')->get('site.Our_mission'); ?></h4>
                                </div>
                                <div class="text"><?php echo app('translator')->get('site.home_our_mission'); ?></div>
                            </div>
                            <div class="text-block">
                                <div class="title">
                                    <span class="count">02</span>
                                    <h4><?php echo app('translator')->get('site.Our_vision'); ?></h4>
                                </div>
                                <div class="text"><?php echo app('translator')->get('site.home_our_vision'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Image Column-->
                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner clearfix">
                        <figure class="image paroller" data-paroller-factor="-0.07" data-paroller-factor-lg="-0.07"
                            data-paroller-factor-md="-0.07" data-paroller-factor-sm="-0.07" data-paroller-type="foreground"
                            data-paroller-direction="horizontal"><img src="<?php echo e(asset('assets/images/home2.png')); ?>" alt="">
                        </figure>
                        <figure class="image paroller" data-paroller-factor="-0.07" data-paroller-factor-lg="-0.07"
                            data-paroller-factor-md="-0.07" data-paroller-factor-sm="-0.07" data-paroller-type="foreground"
                            data-paroller-direction="vertical"><img src="<?php echo e(asset('assets/images/home1.png')); ?>" alt="">
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>

<section class="about-counter-section">
    <!--Counter Section-->
    <div class="container ">
        <div class="sec-title centered">
            <div class="sub-title"><?php echo app('translator')->get('site.Company_Achivement'); ?></div>

        </div>
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="counter">
                    <span class="counter-value">485</span>
                    <h3><?php echo app('translator')->get('site.printing'); ?></h3>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="counter">
                    <span class="counter-value">300</span>
                    <h3><?php echo app('translator')->get('site.translate'); ?></h3>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="counter ">
                    <span class="counter-value">1500</span>
                    <h3><?php echo app('translator')->get('site.Happy_Customers'); ?></h3>
                </div>

            </div>
            <div class="col-md-3 col-sm-6">
                <div class="counter">
                    <span class="counter-value">2010</span>
                    <h3><?php echo app('translator')->get('site.date_create'); ?></h3>
                </div>
            </div>
        </div>
    </div>
</section>

    <!--Services Section-->
    <section class="services-section-four">
        <div class="bubble-dotted">
            <span class="dotted dotted-1"></span>
            <span class="dotted dotted-2"></span>
            <span class="dotted dotted-3"></span>
            <span class="dotted dotted-4"></span>
            <span class="dotted dotted-5"></span>
            <span class="dotted dotted-6"></span>
            <span class="dotted dotted-7"></span>
            <span class="dotted dotted-8"></span>
            <span class="dotted dotted-9"></span>
            <span class="dotted dotted-10"></span>
        </div>
        <div class="faded-text">
            <div class="f-text"><span>services</span></div>
        </div>
        <div class="auto-container">
            <div class="sec-title centered">
                <div class="sub-title"><?php echo app('translator')->get('site.Services'); ?></div>
                <h2><?php echo app('translator')->get('site.What_We_Do'); ?></h2>
            </div>

            <div class="tabs-box services-tabs">
                <div class="tab-buttons">
                    <div class="row clearfix justify-content-center">
                        <div class="col-lg-2 col-md-4 col-md-4 col-sm-6">
                            <div class="btn-inner tab-btn active-btn" data-tab="#tab-1">
                                <span class="icon-bg pe-7s-target"></span>
                                <span class="icon pe-7s-target"></span>
                                <span class="txt"><?php echo app('translator')->get('site.printing'); ?></span>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-4 col-md-4 col-sm-6">
                            <div class="btn-inner tab-btn" data-tab="#tab-2">
                                <span class="icon-bg pe-7s-star"></span>
                                <span class="icon pe-7s-star"></span>
                                <span class="txt"><?php echo app('translator')->get('site.Translate'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tabs-content">
                    <!--Tab-->
                    <div class="tab active-tab" id="tab-1">
                        <div class="tab-inner">
                            <div class="featured-service">
                                <div class="row clearfix">
                                    <!-- Image Column -->
                                    <div class="image-column col-lg-6 col-md-12 col-sm-12">
                                        <div class="inner">
                                            <div class="image-box">
                                                <img src="<?php echo e(asset('assets/images/translate/Brochure-Translation-main.png')); ?>" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Text Column -->
                                    <div class="text-column col-lg-6 col-md-12 col-sm-12">
                                        <div class="inner">
                                            <div class="sec-title left-aligned">
                                                <div class="sub-title"><?php echo app('translator')->get('site.printing'); ?></div>
                                                <h2><?php echo app('translator')->get('site.Our_mission'); ?></h2>
                                            </div>
                                            <div class="text"><?php echo app('translator')->get('site.home_our_mission'); ?> </div>
                                            <div class="link-box clearfix">
                                                <a href="<?php echo e(route('contact')); ?>" class="theme-btn btn-style-nine"><span class="btn-title"><?php echo app('translator')->get('site.Contact'); ?></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Tab-->
                    <div class="tab" id="tab-2">
                        <div class="tab-inner">
                            <div class="featured-service">
                                <div class="row clearfix">
                                    <!-- Image Column -->
                                    <div class="image-column col-lg-6 col-md-12 col-sm-12">
                                        <div class="inner">
                                            <div class="image-box">
                                                <img src="<?php echo e(asset('assets/images/translate/2.jpg')); ?>" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Text Column -->
                                    <div class="text-column col-lg-6 col-md-12 col-sm-12">
                                        <div class="inner">
                                            <div class="sec-title left-aligned">
                                                <div class="sub-title"><?php echo app('translator')->get('site.translate'); ?></div>
                                                <h2><?php echo app('translator')->get('site.Our_mission'); ?></h2>
                                            </div>
                                            <div class="text"><?php echo app('translator')->get('site.home_our_mission'); ?> </div>
                                            <div class="link-box clearfix">
                                                <a href="<?php echo e(route('contact')); ?>" class="theme-btn btn-style-nine"><span class="btn-title"><?php echo app('translator')->get('site.Contact'); ?></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--Testimonial Section-->
    <section class="testimonial-section">
        <div class="image-layer" ></div>
        <div class="auto-container">
            <div class="testimonial-carousel owl-theme owl-carousel">

                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="slide-item">
                    <div class="testimonial-block">
                        <div class="inner-box">
                            <div class="content">

                                <div class="image"><img src="<?php echo e(asset('uploads/'.$testimonial->image)); ?>" alt="" title="" style="height: 100%;object-fit: cover;">
                                    <div class="icon-box"><span class="flaticon-left-quote"></span></div>
                                </div>
                                <div class="info">
                                    <h4><?php echo e($testimonial['name_'.$lang]); ?></h4>
                                    <div class="designation"><?php echo e($testimonial['job_'.$lang]); ?></div>
                                </div>
                                <div class="text">
                                    <?php echo e($testimonial['message_'.$lang]); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/pages/about.blade.php ENDPATH**/ ?>