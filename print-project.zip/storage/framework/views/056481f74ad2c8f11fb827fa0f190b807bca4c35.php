<!-- Vendor js -->
<script src="<?php echo e(asset('dashboard/assets/js/vendor.min.js')); ?>"></script>
<!-- App js-->
<script src="<?php echo e(asset('dashboard/assets/js/app.min.js')); ?>"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/js/pages/form-advanced.init.js')); ?>"></script>
<script>
    $('textarea').val(function(i,v){
    return v.replace(/\s+/g,' ').replace(/>(\s)</g,'>\n<');
});
</script>
<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/layouts-admin/script.blade.php ENDPATH**/ ?>