<?php $__env->startSection('title', __('site.Print')); ?>
<?php $lang = LaravelLocalization::getCurrentLocale(); ?>
<?php $__env->startSection('custom-style'); ?>
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/home-light.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('assets/rtl/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/rtl/css/home-light.css')); ?>" rel="stylesheet">
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Banner Section -->
    <section class="banner-section banner-two">
        <div class="hero-shape-one"></div>
        <div class="hero-shape-two"></div>
        <div class="hero-shape-three"></div>
        <div class="hero-shape-four"></div>
        <div class="hero-shape-five"></div>
        <div class="dotted-bubble-01"></div>
        <div class="dotted-bubble-02"></div>
        <div class="dotted-bubble-03"></div>
        <div class="image-layer"></div>
        <div class="auto-container">
            <div class="content-box">
                <div class="content clearfix">
                    <div class="inner">
                        <div class="sub-title"><?php echo app('translator')->get('site.Print_Maker'); ?></div>
                        <h1><?php echo app('translator')->get('site.Full_service_printing_house'); ?></h1>
                        <div class="text mt-2"><?php echo app('translator')->get('site.print_head'); ?></div>
                        <div class="link-box clearfix mt-4">
                            <a data-target="#about-section" class="theme-btn btn-style-five scroll-to-target"><span
                                    class="btn-title"><?php echo app('translator')->get('site.read_more'); ?></span></a>
                        </div>
                    </div>
                </div>
                <div class="content-image wow slideInRight" data-wow-delay="0ms">
                    <div class="image"><img class="tilt-item"
                            src="<?php echo e(asset('assets/images/p-house3.png')); ?>" alt="" style="margin-top: -40px;">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Banner Section -->

    <!--About Section-->
    <section class="about-section-three pt-5" id="about-section">
        <figure class="floated-image-1"><img src="<?php echo e(asset('assets/images/resource/featured-image-8.jpg')); ?>" alt="">
        </figure>
        <figure class="floated-image-2"><img src="<?php echo e(asset('assets/images/resource/featured-image-9.jpg')); ?>" alt="">
        </figure>
        <div class="auto-container">

            <div class="row clearfix">
                <!--Text Column-->
                <div class="text-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        <div class="sec-title-three left-aligned">
                            <div class="sub-title"><?php echo app('translator')->get('site.About_us'); ?></div>
                            <h2 style="font-size: 50px;"><?php echo app('translator')->get('site.help'); ?></h2>
                            <div class="lower-text" style="font-size: 20px;">
                                <?php echo app('translator')->get('site.about_print'); ?>
                                <br>

                                <br>

                            </div>
                        </div>

                    </div>
                </div>

                <!--Image Column-->
                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner clearfix">
                        <figure class="image paroller" data-paroller-factor="-0.07" data-paroller-factor-lg="-0.07"
                            data-paroller-factor-md="-0.07" data-paroller-factor-sm="-0.07" data-paroller-type="foreground"
                            data-paroller-direction="horizontal"><img src="<?php echo e(asset('assets/images/p-about1.png')); ?>"
                                alt=""></figure>
                        <figure class="image paroller" data-paroller-factor="-0.07" data-paroller-factor-lg="-0.07"
                            data-paroller-factor-md="-0.07" data-paroller-factor-sm="-0.07" data-paroller-type="foreground"
                            data-paroller-direction="vertical"><img src="<?php echo e(asset('assets/images/p-about2.png')); ?>"
                                alt=""></figure>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!--service Section-->
    <section class="team-section">
        <div class="bubble-dotted">
            <span class="dotted dotted-1"></span>
            <span class="dotted dotted-2"></span>
            <span class="dotted dotted-3"></span>
            <span class="dotted dotted-4"></span>
            <span class="dotted dotted-5"></span>
            <span class="dotted dotted-6"></span>
            <span class="dotted dotted-7"></span>
            <span class="dotted dotted-8"></span>
            <span class="dotted dotted-9"></span>
            <span class="dotted dotted-10"></span>
        </div>
        <div class="faded-text">
            <div class="f-text"><span><?php echo app('translator')->get('site.Services'); ?></span></div>
        </div>
        <div class="auto-container">
            <div class="sec-title centered mb-4">
                <div class="sub-title"><?php echo app('translator')->get('site.print_services'); ?></div>
                <h2><?php echo app('translator')->get('site.what_we_do'); ?> </h2>
            </div>
            <hr>
            <section class="portfolio-section-four">
                <div class="auto-container">

                    <div class="sortable-masonry filter-gallery">
                        <div class="filters clearfix">
                            <ul class="filter-tabs filter-btns clearfix">
                                <li class="filter active" data-role="button" data-filter=".all"><?php echo app('translator')->get('site.show_all'); ?></li>
                                <?php $__currentLoopData = $print; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($pr->children()->exists()): ?>
                                    <li class="filter" data-role="button" data-filter=".item-<?php echo e($pr->id); ?>">
                                        <?php echo e($pr['title_' . $lang]); ?></li>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <div class="items-container row clearfix">
                            <!--Gallery Item-->
                            <?php $__currentLoopData = $print; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $pr->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <div
                                        class="gallery-item-two masonry-item all item-<?php echo e($pr->id); ?> col-lg-4 col-md-6 col-sm-12">
                                        <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                                            <div class="image-box">
                                                <figure class="image">
                                                    <?php if($product->imageCategoryPrints()->exists()): ?>
                                                        <a class="lightbox-image"
                                                            href="<?php echo e(asset('uploads/' . $product->imageCategoryPrints[0]->image)); ?>"><img
                                                                src="<?php echo e(asset('uploads/' . $product->imageCategoryPrints[0]->image)); ?>"
                                                                alt=""></a>
                                                    <?php endif; ?>
                                                </figure>
                                                <div class="hover-box">
                                                    <div class="hover-inner">
                                                        <div class="content">
                                                            <h4><a
                                                                    href="<?php echo e(route('print.service', $product->id)); ?>"><?php echo e($product['title_' . $lang]); ?></a>
                                                            </h4>
                                                            <div class="separator"><span class="dot"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="zoom-btn">
                                                        <?php if($product->imageCategoryPrints()->exists()): ?>

                                                            <a class="lightbox-image zoom-link"
                                                                href="<?php echo e(asset('uploads/' . $product->imageCategoryPrints[0]->image)); ?>"
                                                                data-fancybox="gallery"><span
                                                                    class="icon flaticon-expand"></span></a>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="link-btn">
                                                        <a href="<?php echo e(route('print.service', $product->id)); ?>"><span
                                                                class="icon flaticon-link-1"></span></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <a href="<?php echo e(route('print.category_service')); ?>" class="theme-btn btn-style-three btn-readmore m-auto" style="display: block; width:220px"><span class="btn-title" style="letter-spacing: 1px"> <?php echo app('translator')->get('site.all_print_services'); ?></span></a>

                    </div>


                    

                </div>
            </section>

            
    </section>

    <section class="call-to-two ">
        <div class="image-layer" >
            
        </div>
        <div class="auto-container">
            <div class="inner">
                
                <div class="content">
                    <div class="sub-title"><?php echo app('translator')->get('site.call_to_action'); ?></div>
                    <h2><?php echo app('translator')->get('site.now_choose_design'); ?></h2>
                    <div class="link-box">
                        <select name="" id="choose_cat" data-phone="<?php echo e($info->phone); ?>" style="width: 200px; padding: 11px; border-radius: 40px; border: 1px solid #00adef; margin-left: 18px; cursor: pointer">
                            <option selected hidden disabled><?php echo app('translator')->get('site.choose_design'); ?></option>
                            <?php $__currentLoopData = $prints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $print): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($print->title_ar); ?>"><?php echo e($print['title_'.$lang]); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <a target="_blank" href="https://api.whatsapp.com/send/?phone=2<?php echo e($info->phone); ?>&text=السلام عليكم محتاج طلب  لطباعة " id="send-whatsapp" class="theme-btn btn-style-six" style="overflow:inherit;min-width: auto;"><span style="    padding: 14px 73px;
                            background: #00adef;"
                                class="btn-title"><?php echo app('translator')->get('site.Contact'); ?></span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-script'); ?>
    <script>
        $('#choose_cat').on('change', function(){
            val = $(this).val();
            phone = $(this).data('phone');
            href = "https://api.whatsapp.com/send/?phone=2"+phone+"&text=السلام عليكم محتاج طلب  لطباعة "+val;
            $('#send-whatsapp').attr("href", href);
            console.log($phone);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/pages/print.blade.php ENDPATH**/ ?>