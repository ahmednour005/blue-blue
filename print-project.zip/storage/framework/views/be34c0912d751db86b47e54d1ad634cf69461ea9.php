<?php $__env->startSection('title', __('site.service_details')); ?>
<?php $lang = LaravelLocalization::getCurrentLocale(); ?>
<?php $__env->startSection('custom-style'); ?>
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/home-light.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('assets/rtl/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/rtl/css/home-light.css')); ?>" rel="stylesheet">
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Banner Section -->
    <section class="page-banner">
        <div class="image-layer"></div>

        <div class="banner-inner">
            <div class="faded-text light">
                <div class="f-text"><span><?php echo app('translator')->get('site.Services'); ?></span></div>
            </div>
            <div class="auto-container">
                <div class="inner-container clearfix">
                    <h1><?php echo e($print_details['title_' . $lang]); ?></h1>
                    <div class="page-nav">
                        <ul class="bread-crumb clearfix">
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('site.Home'); ?></a></li>
                            <li><a href="<?php echo e(route('print.index')); ?>"><?php echo app('translator')->get('site.Print'); ?></a></li>
                            <?php if($print_details->parent()->exists()): ?>
                                <li><a href="<?php echo e(route('print.service', $print_details->parent->id)); ?>">
                                        <?php echo e($print_details->parent['title_' . $lang]); ?>

                                    </a></li>
                            <?php endif; ?>
                            <li class="active"><?php echo e($print_details['title_' . $lang]); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Banner Section -->


    <div class="project-single">
        <section class="project-details">
            <div class="auto-container">
                <div class="upper-row">
                    <div class="row clearfix">
                        <div class="image-column col-lg-8 col-md-12 col-sm-12">
                            <div class="inner">
                                <?php if($print_details->imageCategoryPrints()->exists()): ?>
                                    <img src="<?php echo e(asset('uploads/' . $print_details->imageCategoryPrints[0]->image)); ?>"
                                        alt="" title="">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="info-column col-lg-4 col-md-12 col-sm-12">
                            <div class="inner">
                                <div class="icon"><span class="flaticon-art"></span></div>
                                <ul class="info">
                                    <li><strong><?php echo app('translator')->get('site.name'); ?></strong> <br><?php echo e($print_details['title_' . $lang]); ?>

                                    </li>
                                    <?php if($print_details->parent()->exists()): ?>
                                        <li><strong><?php echo app('translator')->get('site.category'); ?></strong>
                                            <br><?php echo e($print_details->parent['title_' . $lang]); ?>

                                        </li>
                                    <?php endif; ?>

                                </ul>
                                <a target="_blank"
                                    href="https://api.whatsapp.com/send/?phone=2<?php echo e($phone); ?>&text=السلام عليكم محتاج طلب  لطباعة <?php echo e($print_details->title_ar); ?>">
                                    <img src="<?php echo e(asset('assets/images/whatsapp--v6.png')); ?>" />
                                </a> <br><?php echo app('translator')->get('site.order_now'); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="content-row">
                    <h3><?php echo e($print_details['title_' . $lang]); ?></h3>
                    <p><?php echo e($print_details['subtitle_' . $lang]); ?></p>
                    <p><?php echo e($print_details['describe_' . $lang]); ?></p>

                </div>
            </div>
        </section>
    </div>

    <div class="screen-shot parallax section lb" style="background: #fbfbfb;padding: 20px 0;">
        <div class="container">
            <div class="project-carousel owl-theme owl-carousel">
                <?php $__currentLoopData = $print_details->imageCategoryPrints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="service-widget">
                        <div class="post-media wow fadeIn">
                            
                                <a class="lightbox-image" href="<?php echo e(asset('uploads/' . $image->image)); ?>"><img
                                    src="<?php echo e(asset('uploads/' . $image->image)); ?>" style="height: 300px; object-fit: contain;border: 1px solid #DDD;"
                                    alt=""></a>
                            
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/pages/print_service_details.blade.php ENDPATH**/ ?>