<head>
    <meta charset="utf-8">
    <title>Blue Blue | <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Stylesheets -->
    <link href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('custom-style'); ?>
    <!-- Responsive File -->
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
        <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('assets/rtl/css/responsive.css')); ?>" rel="stylesheet">
    <?php endif; ?>

    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="icon" href="images/favicon.png" type="image/x-icon">

    <!-- Responsive Settings -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>
<?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/includes/header.blade.php ENDPATH**/ ?>