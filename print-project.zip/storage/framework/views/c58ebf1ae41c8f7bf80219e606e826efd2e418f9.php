<!DOCTYPE html>
<html <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?> lang="en" <?php else: ?>  lang="ar" <?php endif; ?>>
<?php echo $__env->make('front.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="home-light-style">

    <div class="page-wrapper">
       <?php echo $__env->make('front.includes.translatenavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('front.includes.translatefooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo $__env->make('front.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/layouts/master2.blade.php ENDPATH**/ ?>