    <!--Scroll to top-->
    <div class="scroll-to-top scroll-to-target" data-target="html"><span class="flaticon-up-arrow"></span></div>

    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.fancybox.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/knob.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/paroller.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/tilt.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/isotope.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/appear.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/element-in-view.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/validate.js')); ?>"></script>
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
    <script src="<?php echo e(asset('assets/js/custom-script.js')); ?>"></script>
    <?php else: ?>
    <script src="<?php echo e(asset('assets/rtl/js/custom-script.js')); ?>"></script>
    <?php endif; ?>

    <!--Google Map-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBHJe2MPH8B-gLzZu5QI0Alc73nvkLuuqQ"></script>
    <script src="<?php echo e(asset('assets/js/map-script.js')); ?>"></script>
<?php echo $__env->yieldContent('custom-script'); ?>
<?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/includes/script.blade.php ENDPATH**/ ?>