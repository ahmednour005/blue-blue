<?php $__env->startSection('title',__('site.trans_descrip')); ?>
<?php $lang = LaravelLocalization::getCurrentLocale(); ?>
<?php $__env->startSection('custom-style'); ?>
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
        <link href="<?php echo e(asset('assets/css2/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css2/home-light.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('assets/rtl/css2/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/rtl/css2/home-light.css')); ?>" rel="stylesheet">
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Banner Section -->
    <section class="page-banner ">
        <div class="banner-inner">
            <div class="faded-text light">
                <div class="f-text"><span><?php echo app('translator')->get('site.Services'); ?></span></div>
            </div>
            <div class="auto-container">
                <div class="inner-container clearfix">
                    <h1><?php echo e($translation['title_' . $lang]); ?></h1>
                    <div class="page-nav">
                        <ul class="bread-crumb clearfix">
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('site.Home'); ?></a></li>
                            <li><a href="<?php echo e(route('translate.index')); ?>"><?php echo app('translator')->get('site.Translate'); ?></a></li>
                            <li class="active"><?php echo e($translation['title_' . $lang]); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Banner Section -->

    <div class="project-single">
        <section class="project-details">
            <div class="auto-container">
                <div class="upper-row">
                    <div class="row clearfix">
                        <div class="image-column col-lg-8 col-md-12 col-sm-12">
                            <div class="inner">
                                <img src="<?php echo e(asset('uploads/' . $translation->image)); ?>" alt="" title="">
                            </div>
                        </div>
                        <div class="info-column col-lg-4 col-md-12 col-sm-12">
                            <form method="post" action="<?php echo e(route('count-file')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="inner">
                                    <div class="icon"><span class="flaticon-art"></span></div>
                                    <ul class="info">

                                        <input name="id" type="hidden" value="<?php echo e($translation->id); ?>">
                                        <li> <input type="file" name="file" accept=".docx,.pdf"><br><?php echo app('translator')->get('site.upload_w_f'); ?>
                                        </li>
                                        <li><input type="number" min="0" name="number"
                                                style="background: rgb(221, 221, 221); width: 220px; height: 30px;">
                                            <br><?php echo app('translator')->get('site.enter_words_count'); ?>
                                        </li>
                                        <li>
                                            <div class="mb-3">
                                                <?php if($price != 0): ?>
                                                    <?php echo app('translator')->get('site.the_price'); ?> : <?php echo e($price * $translation->price); ?>

                                                    <?php echo app('translator')->get('site.egy'); ?>
                                                <?php endif; ?>
                                            </div>
                                            <button type="submit" class="theme-btn btn-style-four"><span
                                                    class="btn-title"><?php echo app('translator')->get('site.live_Price'); ?> </span></button>
                                        </li>
                                        <li>
                                            <a target="_blank"
                                                href="https://api.whatsapp.com/send/?phone=2<?php echo e($phone); ?>&text=السلام عليكم  محتاج طلب اوردر (ترجمة) <?php echo e($translation->title_ar); ?>"><img
                                                    src="https://img.icons8.com/color/48/000000/whatsapp--v6.png" /></a>
                                            <br><?php echo app('translator')->get('site.Contact'); ?>
                                        </li>

                                    </ul>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="content-row">
                    <h3><?php echo e($translation['title_' . $lang]); ?></h3>
                    <p>
                        <?php echo e($translation['describe_' . $lang]); ?>

                    </p>
                </div>
            </div>
        </section>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/pages/translate_service.blade.php ENDPATH**/ ?>