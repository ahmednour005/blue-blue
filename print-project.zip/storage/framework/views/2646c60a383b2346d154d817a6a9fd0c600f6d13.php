<?php $__env->startSection('title', __('site.Home')); ?>
<?php $lang = LaravelLocalization::getCurrentLocale(); ?>
<?php $__env->startSection('custom-style'); ?>
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/home-light.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('assets/rtl/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/rtl/css/home-light.css')); ?>" rel="stylesheet">
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Banner Section -->
    <section class="banner-section banner-five">
        <div class="hero-shape-one"></div>
        <div class="hero-shape-two"></div>
        <div class="hero-shape-three"></div>
        <div class="hero-shape-four"></div>
        <div class="hero-shape-five"></div>
        <div class="dotted-bubble-01"></div>
        <div class="dotted-bubble-02"></div>
        <div class="dotted-bubble-03"></div>
        <div class="left-shape-layer" style="background-image: url(<?php echo e(asset('assets/images/background/shape-1.png')); ?>">
        </div>
        <div class="auto-container">
            <div class="content-box">
                <div class="content clearfix">
                    <div class="inner">
                        <div class="sub-title"><?php echo app('translator')->get('site.printing_and_translate'); ?> </div>
                        <h1>BLUE BLUE</h1>
                        <img class="xerox" src="<?php echo e(asset('assets/images/xerox.jpeg')); ?>" alt="">
                        <div class="link-box clearfix">
                            <a href="<?php echo e(route('translate.index')); ?>" class="theme-btn btn-style-nine"><span
                                    class="btn-title"><?php echo app('translator')->get('site.Translate'); ?></span></a>
                            <a href="<?php echo e(route('print.index')); ?>" class="theme-btn btn-style-five"><span
                                    class="btn-title"><?php echo app('translator')->get('site.Print'); ?></span></a>
                        </div>
                    </div>
                </div>
                <div class="scroll-down">
                    <div class="scroll-to-target" data-target="#scroll-section"><span
                            class="icon flaticon-right-arrow"></span></div>
                </div>
            </div>
        </div>
    </section>
    <!--End Banner Section -->

    <!--About Section-->
    <section class="about-section-three" id="scroll-section">
        <figure class="floated-image-1"><img src="<?php echo e(asset('assets/images/resource/featured-image-8.jpg')); ?>" alt="">
        </figure>
        <figure class="floated-image-2"><img src="<?php echo e(asset('assets/images/resource/featured-image-9.jpg')); ?>" alt="">
        </figure>
        <div class="auto-container">

            <div class="row clearfix">
                <!--Text Column-->
                <div class="text-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner">
                        <div class="sec-title-three left-aligned">
                            <div class="sub-title"><?php echo app('translator')->get('site.About_us'); ?></div>
                            <h2><?php echo app('translator')->get('site.About_us_title'); ?></h2>
                            <div class="lower-text"><?php echo app('translator')->get('site.About_us_sub_title'); ?></div>
                        </div>
                        <div class="text-content">
                            <div class="text-block">
                                <div class="title">
                                    <span class="count">01</span>
                                    <h4><?php echo app('translator')->get('site.Our_mission'); ?></h4>
                                </div>
                                <div class="text"><?php echo app('translator')->get('site.home_our_mission'); ?></div>
                            </div>
                            <div class="text-block">
                                <div class="title">
                                    <span class="count">02</span>
                                    <h4><?php echo app('translator')->get('site.Our_vision'); ?></h4>
                                </div>
                                <div class="text"><?php echo app('translator')->get('site.home_our_vision'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--Image Column-->
                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner clearfix">
                        <figure class="image paroller" data-paroller-factor="-0.07" data-paroller-factor-lg="-0.07"
                            data-paroller-factor-md="-0.07" data-paroller-factor-sm="-0.07" data-paroller-type="foreground"
                            data-paroller-direction="horizontal"><img src="<?php echo e(asset('assets/images/home2.png')); ?>"
                                alt="">
                        </figure>
                        <figure class="image paroller" data-paroller-factor="-0.07" data-paroller-factor-lg="-0.07"
                            data-paroller-factor-md="-0.07" data-paroller-factor-sm="-0.07" data-paroller-type="foreground"
                            data-paroller-direction="vertical"><img src="<?php echo e(asset('assets/images/home1.png')); ?>" alt="">
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--Team Section-->
    <section class="team-section">
        <div class="bubble-dotted">
            <span class="dotted dotted-1"></span>
            <span class="dotted dotted-2"></span>
            <span class="dotted dotted-3"></span>
            <span class="dotted dotted-4"></span>
            <span class="dotted dotted-5"></span>
            <span class="dotted dotted-6"></span>
            <span class="dotted dotted-7"></span>
            <span class="dotted dotted-8"></span>
            <span class="dotted dotted-9"></span>
            <span class="dotted dotted-10"></span>
        </div>
        <div class="faded-text">
            <div class="f-text"><span><?php echo app('translator')->get('site.Services'); ?></span></div>
        </div>
        <div class="auto-container">
            <div class="sec-title centered mb-2">
                <div class="sub-title"><?php echo app('translator')->get('site.Services'); ?></div>
                <h2><?php echo app('translator')->get('site.what_we_do'); ?></h2>
            </div>
            <div class="sec-title style-three light centered mb-0">
                <div class="sub-title mb-0"><?php echo app('translator')->get('site.print_services'); ?></div>
            </div>
            <hr>

            <div class="team-carousel owl-theme owl-carousel">
                <?php $__currentLoopData = $print; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Block-->
                    <div class="team-block">
                        <div class="inner-box text-center">
                            <div class="image-box">
                                <?php if($pr->imageCategoryPrints()->exists()): ?>
                                    <figure class="image"><img
                                            src="<?php echo e(asset('uploads/' . $pr->imageCategoryPrints[0]->image)); ?>" alt=""
                                            title="">
                                    </figure>
                                <?php endif; ?>
                            </div>
                            <div class="lower-box">
                                <div class="count">
                                    <?php if($translate->count() <= 9): ?>
                                        <span> 0<?php echo e($loop->iteration); ?> </span>
                                    <?php else: ?>
                                        <span><?php echo e($loop->iteration); ?> </span>
                                    <?php endif; ?>
                                </div>
                                <h3 class="name"><?php echo e($pr['title_' . $lang]); ?></h3>
                                <div class="features">
                                    <p>
                                        <?php echo e($pr['subtitle_' . $lang]); ?>

                                    </p>
                                </div>
                                <a href="<?php echo e(route('print.service', $pr->id)); ?>"
                                    class="theme-btn btn-style-three btn-readmore"><span
                                        class="btn-title"><?php echo app('translator')->get('site.read_more'); ?></span></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
            <div class="sec-title style-three light centered mb-0">
                <div class="sub-title mb-0"><?php echo app('translator')->get('site.translate_services'); ?></div>
            </div>
            <hr>
            <div class="team-carousel owl-theme owl-carousel">
                <?php $__currentLoopData = $translate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Block-->
                    <div class="team-block">
                        <div class="inner-box text-center">
                            <div class="image-box">
                                <figure class="image"><img src="<?php echo e(asset('uploads/' . $tr->image)); ?>" alt=""
                                        title="">
                                </figure>
                            </div>
                            <div class="lower-box">
                                <div class="count">
                                    <?php if($translate->count() <= 9): ?>
                                        <span> 0<?php echo e($loop->iteration); ?> </span>
                                    <?php else: ?>
                                        <span><?php echo e($loop->iteration); ?> </span>
                                    <?php endif; ?>
                                </div>
                                <h3 class="name"><?php echo e($tr['title_' . $lang]); ?></h3>
                                <div class="features">
                                    <p>
                                        <?php echo e($tr['subtitle_' . $lang]); ?>

                                    </p>
                                </div>
                                <a href="<?php echo e(route('translate.service', $tr->id)); ?>"
                                    class="theme-btn btn-style-three btn-readmore"><span
                                        class="btn-title"><?php echo app('translator')->get('site.read_more'); ?></span></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>


    <!--Contact Section-->
    <section class="info-section">
        <div class="bubble-dotted">
            <span class="dotted dotted-1"></span>
            <span class="dotted dotted-2"></span>
            <span class="dotted dotted-3"></span>
            <span class="dotted dotted-4"></span>
            <span class="dotted dotted-5"></span>
            <span class="dotted dotted-6"></span>
            <span class="dotted dotted-7"></span>
            <span class="dotted dotted-8"></span>
            <span class="dotted dotted-9"></span>
            <span class="dotted dotted-10"></span>
        </div>
        <div class="image-layer" style="background-image: url(images/background/image-5.jpg);"></div>
        <div class="faded-text style-two light">
            <div class="f-text"><span><?php echo app('translator')->get('site.Contact'); ?></span></div>
        </div>
        <div class="auto-container">
            <div class="sec-title-three light centered">
                <div class="sub-title"><?php echo app('translator')->get('site.Contact'); ?></div>
                <h2><?php echo app('translator')->get('site.get_in_touch'); ?></h2>
            </div>
            <div class="info">
                <div class="row clearfix">
                    <!--Info Block-->
                    <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                        <div class="inner hvr-bob">
                            <div class="icon-box"><span class="flaticon-call"></span></div>
                            <h4><?php echo app('translator')->get('site.phone_number'); ?></h4>
                            <ul>
                                <li><a href="tel:<?php echo e($info->phone); ?>"><?php echo e($info->phone); ?></a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <!--Info Block-->
                    <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                        <div class="inner hvr-bob">
                            <div class="icon-box"><span class="flaticon-envelope"></span></div>
                            <h4><?php echo app('translator')->get('site.email_address'); ?></h4>
                            <ul>
                                <li><a href="mailto:<?php echo e($info->email); ?>"><?php echo e($info->email); ?></a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <!--Info Block-->
                    <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                        <div class="inner hvr-bob">
                            <div class="icon-box"><span class="flaticon-worldwide-1"></span></div>
                            <h4><?php echo app('translator')->get('site.web_address'); ?></h4>
                            <ul>
                                <li><a href="<?php echo e(route('print.index')); ?>"><?php echo app('translator')->get('site.Print'); ?></a></li>
                                <li><a href="<?php echo e(route('translate.index')); ?>"><?php echo app('translator')->get('site.Translate'); ?></a></li>
                            </ul>
                        </div>
                    </div>
                    <!--Info Block-->
                    <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                        <div class="inner hvr-bob">
                            <div class="icon-box"><span class="flaticon-placeholder-3"></span></div>
                            <h4><?php echo app('translator')->get('site.office_address'); ?></h4>
                            <ul>
                                <li><a href="https://goo.gl/maps/VynUuqoo1iUTSjfL7" target="_blank">
                                        <?php echo app('translator')->get('site.comapny_address'); ?>
                                    </a></li>
                            </ul>
                        </div>
                    </div>
                    <a href="<?php echo e(route('contact')); ?>" class="theme-btn btn-style-three btn-contact"><span
                            class="btn-title"><?php echo app('translator')->get('site.Contact'); ?></span></a>
                </div>
            </div>


        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/home.blade.php ENDPATH**/ ?>