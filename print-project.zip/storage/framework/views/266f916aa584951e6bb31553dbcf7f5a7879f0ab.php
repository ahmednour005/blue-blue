<?php $__env->startSection('title',__('site.Translate')); ?>
<?php $lang = LaravelLocalization::getCurrentLocale(); ?>
<?php $__env->startSection('custom-style'); ?>
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
        <link href="<?php echo e(asset('assets/css2/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css2/home-light.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('assets/rtl/css2/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/rtl/css2/home-light.css')); ?>" rel="stylesheet">
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Banner Section -->
    <section class="banner-section banner-two">
        <div class="image-layer" <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?> style="background-image: url(<?php echo e(asset('assets/images/main-slider/2.png')); ?>);" <?php else: ?> style="background-image: url(<?php echo e(asset('assets/images/header-bg-rtl.png')); ?>);" <?php endif; ?>></div>
        <div class="auto-container">
            <div class="content-box">
                <div class="content clearfix">
                    <div class="inner">
                        <div class="sub-title"><?php echo app('translator')->get('site.blueblue_translate'); ?></div>
                        <h1><?php echo app('translator')->get('site.ask_order'); ?> <?php echo app('translator')->get('site.translate'); ?></h1>
                        <div class="text"><?php echo app('translator')->get('site.trans_descrip'); ?></div>
                        <div class="link-box clearfix">
                            <a href="<?php echo e(route('contact')); ?>" class="theme-btn btn-style-four"><span
                                    class="btn-title"><?php echo app('translator')->get('site.Contact'); ?> </span></a>
                            <a data-target="#about-section" class="theme-btn btn-style-five scroll-to-target"><span
                                    class="btn-title"><?php echo app('translator')->get('site.learn_more'); ?> </span></a>
                        </div>
                    </div>
                </div>
                <div class="content-image wow slideInRight" data-wow-delay="0ms">
                    <div class="image"><img class="tilt-item"
                            src="<?php echo e(asset('assets/images/translate/translate1.png')); ?>" alt=""></div>
                </div>
            </div>
        </div>
    </section>
    <!--End Banner Section -->

    <!--Services Section-->
    <section class="features-section" id="about-section">
        <div class="auto-container">
            <div class="faded-text">
                <div class="f-text"><span><?php echo app('translator')->get('site.Services'); ?></span></div>
            </div>
            <div class="auto-container">
                <div class="sec-title centered mb-4">
                    <div class="sub-title"><?php echo app('translator')->get('site.translate_services'); ?></div>
                    <h2><?php echo app('translator')->get('site.avilable_lang'); ?> </h2>
                </div>
                <hr>
                <div class="row clearfix">
                    <?php $__currentLoopData = $translate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--Block-->
                        <div class="feature-block col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="inner-box hvr-bob">
                                <div class="pattern-layer"></div>
                                <div class="count">
                                    <?php if($translate->count() <= 9): ?>
                                        <span> 0<?php echo e($loop->iteration); ?> </span>
                                    <?php else: ?>
                                        <span><?php echo e($loop->iteration); ?> </span>
                                    <?php endif; ?>
                                </div>
                                <div class="icon-box"><img class="translate-card-image" src="<?php echo e(asset('uploads/'.$tr->image)); ?>" alt=""></span></div>
                                <h4><?php echo e($tr['title_'.$lang]); ?></h4>
                                <div class="text"><?php echo e($tr['subtitle_' . $lang]); ?></div>
                                <div class="more-link"><a
                                        href="<?php echo e(route('translate.service', $tr->id)); ?>"><?php echo app('translator')->get('site.read_more'); ?></a></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

            </div>
    </section>

    <section class="call-to-two ">
        <div class="image-layer" >
            
        </div>
        <div class="auto-container">
            <div class="inner">
                
                <div class="content">
                    <div class="sub-title"><?php echo app('translator')->get('site.call_to_action'); ?></div>
                    <h2><?php echo app('translator')->get('site.we_are_here'); ?></h2>
                    <div class="link-box">
                        <a href="<?php echo e(route('contact')); ?>" class="theme-btn btn-style-six"><span
                                class="btn-title"><?php echo app('translator')->get('site.Contact'); ?></span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/pages/translate_index.blade.php ENDPATH**/ ?>