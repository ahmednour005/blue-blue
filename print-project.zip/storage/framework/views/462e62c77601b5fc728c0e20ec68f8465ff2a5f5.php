<?php $__env->startSection('title', __('site.Contact')); ?>
<?php $__env->startSection('custom-style'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.9/sweetalert2.min.css" />
    <?php if(LaravelLocalization::getCurrentLocale() == 'en'): ?>
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/home-light.css')); ?>" rel="stylesheet">
    <?php else: ?>
        <link href="<?php echo e(asset('assets/rtl/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/rtl/css/home-light.css')); ?>" rel="stylesheet">
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Banner Section -->
    <section class="page-banner">
        <div class="image-layer"></div>
        <div class="banner-inner">
            <div class="faded-text light">
                <div class="f-text"><span><?php echo app('translator')->get('site.Contact'); ?></span></div>
            </div>
            <div class="auto-container">
                <div class="inner-container clearfix">
                    <h1><?php echo app('translator')->get('site.Contact'); ?></h1>
                    <div class="page-nav">
                        <ul class="bread-crumb clearfix">
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('site.Home'); ?></a></li>
                            <li class="active"><?php echo app('translator')->get('site.Contact'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--End Banner Section -->

        <!--Contact Section-->
        <section class="contact-section">
            <div class="auto-container">

                <div class="row clearfix">

                    <div class="form-column col-lg-6 col-md-12">
                        <div class="inner">
                            <div class="sec-title left-aligned">
                                <div class="sub-title"><?php echo app('translator')->get('site.Contact'); ?></div>
                                <!-- <h2>drop us a line with estimate</h2> -->
                            </div>
                            <div class="form-box">
                                <div class="default-form contact-form">
                                    
                                    <div class="form-group">
                                        <div class="field-inner">
                                            <input type="text" name="name" placeholder="<?php echo app('translator')->get('site.Enter_your_name'); ?>"
                                                required class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <p class="error"
                                                style="color: red;font-size: 12px;font-weight: 700;margin-top: 8px;"> </p>

                                            <div class="field-icon"><span class="flaticon-people"></span></div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="field-inner">
                                            <input type="text" name="phone" placeholder="<?php echo app('translator')->get('site.Enter_your_phone'); ?>"
                                                required class="<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <p class="error"
                                                style="color: red;font-size: 12px;font-weight: 700;margin-top: 8px;"> </p>


                                            <div class="field-icon"><span class="flaticon-call"></span></div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="field-inner">
                                            <input type="email" name="email" placeholder="<?php echo app('translator')->get('site.Enter_your_email'); ?>"
                                                required class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                            <div class="field-icon"><span class="flaticon-envelope"></span></div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="field-inner">
                                            <textarea name="message" placeholder="<?php echo app('translator')->get('site.Type_your_message'); ?>"
                                                class="<?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required></textarea>
                                            <p class="error"
                                                style="color: red;font-size: 12px;font-weight: 700;margin-top: 8px;"> </p>

                                            <div class="field-icon"><span class="flaticon-edit"></span></div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="btn-box">
                                            <button class="theme-btn btn-style-nine contact-form"><span
                                                    class="btn-title"><?php echo app('translator')->get('site.Submit_Now'); ?></span></button>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="map-column col-lg-6 col-md-12">
                        <div class="inner">
                            <div class="map-box"
                                style="border:1px solid #DDD; box-shadow: 0 0 5px rgb(0 0 0 / 20%);">
                                <div style="width: 100%"><iframe width="100%" height="500" frameborder="0" scrolling="no"
                                        marginheight="0" marginwidth="0"
                                        src="https://maps.google.com/maps?width=100%25&amp;height=500&amp;hl=en&amp;q=Syria,%20Gazirat%20Mit%20Oqbah,%20Agouza,%20Giza%20Governorate+(Blue%20Blue)&amp;t=&amp;z=18&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"><a
                                            href="http://www.gps.ie/">vehicle gps</a></iframe></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <!--Contact Section-->
        <section class="info-section">


            <div class="auto-container">

                <div class="info">
                    <div class="row clearfix">
                        <!--Info Block-->
                        <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="inner hvr-bob">
                                <div class="icon-box"><span class="flaticon-call"></span></div>
                                <h4><?php echo app('translator')->get('site.phone_number'); ?></h4>
                                <ul>
                                    <li><a href="tel:<?php echo e($info->phone); ?>"><?php echo e($info->phone); ?></a></li>
                                    
                                </ul>
                            </div>
                        </div>
                        <!--Info Block-->
                        <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="inner hvr-bob">
                                <div class="icon-box"><span class="flaticon-envelope"></span></div>
                                <h4><?php echo app('translator')->get('site.email_address'); ?></h4>
                                <ul>
                                    <li><a href="mailto:<?php echo e($info->email); ?>"><?php echo e($info->email); ?></a></li>
                                    
                                </ul>
                            </div>
                        </div>
                        <!--Info Block-->
                        <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="inner hvr-bob">
                                <div class="icon-box"><span class="flaticon-worldwide-1"></span></div>
                                <h4><?php echo app('translator')->get('site.web_address'); ?></h4>
                                <ul>
                                    <li><a href="<?php echo e(route('print.index')); ?>"><?php echo app('translator')->get('site.Print'); ?></a></li>
                                    <li><a href="<?php echo e(route('translate.index')); ?>"><?php echo app('translator')->get('site.Translate'); ?></a></li>
                                </ul>
                            </div>
                        </div>
                        <!--Info Block-->
                        <div class="info-box col-xl-3 col-lg-6 col-md-6 col-sm-12">
                            <div class="inner hvr-bob">
                                <div class="icon-box"><span class="flaticon-placeholder-3"></span></div>
                                <h4><?php echo app('translator')->get('site.office_address'); ?></h4>
                                <ul>
                                    <li><a href="https://goo.gl/maps/VynUuqoo1iUTSjfL7" target="_blank">
                                            <?php echo app('translator')->get('site.comapny_address'); ?>
                                        </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </section>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('custom-script'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.9/sweetalert2.all.min.js"></script>


        <script>
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3500,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })

            function validation() {
                valid = true;
                if ($("input[name=name]").val() == '') {
                    $("input[name=name]").next('.error').text('من فضلك ادخل الأسم');
                    valid = false;
                } else {
                    $("input[name=name]").next('.error').text('');
                    valid = true;
                }

                if ($("input[name=phone]").val() == '') {
                    $("input[name=phone]").next('.error').text('من فضلك ادخل رقم الموبايل');
                    valid = false;
                } else {
                    $("input[name=phone]").next('.error').text('');
                    valid = true;
                }

                if ($("textarea[name=message").val() == '') {
                    $("textarea[name=message").next('.error').text('من فضلك ادخل الرسالة');
                    valid = false;
                } else {
                    $("textarea[name=message").next('.error').text('');
                    valid = true;
                }
                return valid;
            }
            $("input[name=name]").on('keyup',function(){
                validation();
            });
            $("input[name=phone]").on('keyup',function(){
                validation();
            });
            $("textarea[name=message").on('keyup',function(){
                validation();
            });

            $('.theme-btn.btn-style-nine.contact-form').on('click', function(e) {
                if (validation()) {
                    name = $("input[name=name]").val();
                    email = $("input[name=email]").val();
                    phone = $("input[name=phone]").val();
                    message = $("textarea[name=message]").val();

                    $.ajax({
                        url: "<?php echo e(route('contacts_form.store')); ?>",
                        type: "POST",
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>",
                            name: name,
                            email: email,
                            phone: phone,
                            message: message,
                        },
                        success: function(response) {
                            $("input[name=name]").val('');
                            $("input[name=email]").val('');
                            $("input[name=phone]").val('');
                            $("textarea[name=message]").val('');
                            Toast.fire({
                                icon: 'success',
                                title: 'لقد تم ارسال طلبك بنجاح'
                            })
                        },
                    });
                }
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/front/pages/contact.blade.php ENDPATH**/ ?>