

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('dashboard/assets/libs/flatpickr/flatpickr.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('dashboard/assets/libs/selectize/css/selectize.bootstrap3.css')); ?>" rel="stylesheet"
    type="text/css" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">الملف الشخصي</a></li>
                        <li class="breadcrumb-item active">      لوحة التحكم</li>
                    </ol>
                </div>
                <h4 class="page-title">      لوحة التحكم</h4>
            </div>
        </div>
    </div>
    <!-- end page title -->

    <div class="row">


    </div>
    <!-- end row-->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('setting.add-setting')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <h5 class="my-4 text-uppercase "><i class="mdi mdi-account-circle me-1"></i>
                            اعدادات عامة
                        </h5>

                        <div class="row">


                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="email" class="form-label">  بريد الكتروني</label>
                                    <input type="text" value="<?php echo e(old('email',$setting->email)); ?>" name="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="email" required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>


                        <div class="row">


                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="phone" class="form-label">  رقم الموبيل</label>
                                    <input type="number"  value="<?php echo e(old('phone',$setting->phone)); ?>" name="phone"
                                        class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="phone" required>
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>

                        <div class="row">


                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="address" class="form-label">   العنوان</label>
                                    <input type="text" value="<?php echo e(old('address',$setting->address)); ?>" name="address"
                                        class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="address" required>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>
                        <div class="text-end">

                            <button type="submit" class="btn btn-success waves-effect waves-light mt-2"><i
                                    class="mdi mdi-content-save"></i> حفظ</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>



    </div>
    <!-- end row -->




</div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('dashboard/assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>

<script src="<?php echo e(asset('dashboard/assets/libs/selectize/js/standalone/selectize.min.js')); ?>"></script>

<!-- Dashboar 1 init js-->
<script src="<?php echo e(asset('dashboard/assets/js/pages/dashboard-1.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts-admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eec\Documents\GitHub\print-project\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>